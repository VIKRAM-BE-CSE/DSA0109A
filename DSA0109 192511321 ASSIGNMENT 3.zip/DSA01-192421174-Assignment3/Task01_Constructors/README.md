# Task01_Constructors

Source: `main.cpp`

Compile: `g++ -std=c++17 -Wall -Wextra -pedantic main.cpp -o main`

Run: `./main`
